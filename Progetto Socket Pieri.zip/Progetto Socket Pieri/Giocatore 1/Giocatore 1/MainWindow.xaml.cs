﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Windows;
using System.Windows.Threading;

namespace Socket_4I
{
    public partial class MainWindow : Window
    {
        Socket socket = null;
        DispatcherTimer dTimer = null;
        int nRoll = 3;
        string card1 = "";
        string card2 = "";

        public MainWindow()
        {
            InitializeComponent();

            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            IPAddress local_address = IPAddress.Any;
            IPEndPoint local_endpoint = new IPEndPoint(local_address, 50000);

            socket.Bind(local_endpoint);

            dTimer = new DispatcherTimer();
            dTimer.Tick += new EventHandler(aggiornamento_dTimer);
            dTimer.Interval = new TimeSpan(0, 0, 0, 0, 250);
            dTimer.Start();
        }

        private void aggiornamento_dTimer(object sender, EventArgs e)
        {
            int nBytes = 0;

            if ((nBytes = socket.Available) > 0)
            {
                byte[] buffer = new byte[nBytes];
                EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

                nBytes = socket.ReceiveFrom(buffer, ref remoteEndPoint);
                string from = ((IPEndPoint)remoteEndPoint).Address.ToString();
                string messaggio = Encoding.UTF8.GetString(buffer, 0, nBytes);

                if (IsCard(messaggio))
                {
                    card2 = messaggio;
                    if (card1 != "")
                    {
                        string greaterCard = CompareCards(card1, card2);
                        lstMessaggi.Items.Add("Judge: " + greaterCard);
                        card1 = "";
                        card2 = "";
                    }
                }
                else
                {
                    lstMessaggi.Items.Add(from + ": " + messaggio);
                }
            }
        }

        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            IPAddress remote_address = IPAddress.Parse(txtTo.Text);
            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 60000);

            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);
            socket.SendTo(messaggio, remote_endpoint);

            lstMessaggi.Items.Add("You: " + txtMessaggio.Text);
            txtMessaggio.Clear();
        }

        private void btnInvia_Number(object sender, RoutedEventArgs e)
        {
            nRoll = 3;
            btnRollNumber.Content = $"Roll({nRoll})";

            IPAddress remote_address = IPAddress.Parse(txtTo.Text);
            IPEndPoint remote_endpoint = new IPEndPoint(remote_address, 60000);

            byte[] messaggio = Encoding.UTF8.GetBytes(txtNumber.Text);
            socket.SendTo(messaggio, remote_endpoint);

            lstMessaggi.Items.Add("You: " + txtNumber.Text);
            card1 = txtNumber.Text;
            if (card2 != "")
            {
                string greaterCard = CompareCards(card1, card2);
                lstMessaggi.Items.Add("Judge: " + greaterCard);
                card1 = "";
                card2 = "";
            }
            txtNumber.Clear();

        }

        private string RandomCard()
        {
            string[] suits = { "Hearts", "Diamonds", "Clubs", "Spades" };
            string[] values = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };

            Random rand = new Random();
            string suit = suits[rand.Next(suits.Length)];
            string value = values[rand.Next(values.Length)];

            return ($"{value} of {suit}");
        }

        private void btnRollNumber_Click(object sender, RoutedEventArgs e)
        {
            if (nRoll > 0)
            {
                txtNumber.Text = RandomCard();
                nRoll--;
                btnRollNumber.Content = $"Roll({nRoll})";
            }
        }

        private string CompareCards(string card1, string card2)
        {
            string[] values = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
            string[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };

            string[] card1Parts = card1.Split(new[] { " of " }, StringSplitOptions.None);
            string[] card2Parts = card2.Split(new[] { " of " }, StringSplitOptions.None);

            int value1 = Array.IndexOf(values, card1Parts[0]);
            int value2 = Array.IndexOf(values, card2Parts[0]);

            if (value1 > value2) return card1;
            if (value1 < value2) return card2;

            int suit1 = Array.IndexOf(suits, card1Parts[1]);
            int suit2 = Array.IndexOf(suits, card2Parts[1]);

            return suit1 > suit2 ? card1 : card2;
        }

        private bool IsCard(string message)
        {
            string[] values = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
            string[] suits = { "Clubs", "Diamonds", "Hearts", "Spades" };

            string[] parts = message.Split(new[] { " of " }, StringSplitOptions.None);
            if (parts.Length != 2) return false;

            string value = parts[0];
            string suit = parts[1];

            return Array.Exists(values, v => v == value) && Array.Exists(suits, s => s == suit);
        }
    }
}
